package com.ecommerce.paymentservice;

// payment service
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DummyPaymentApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
